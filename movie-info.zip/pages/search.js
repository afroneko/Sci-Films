const movies = [
    "Arrival",
    "Gardians of the galaxy",
    "Interstellar"
];

jQuery("#movies-search").autocomplete({
    source: movies
});